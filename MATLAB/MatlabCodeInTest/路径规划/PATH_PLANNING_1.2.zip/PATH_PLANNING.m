function PATH_PLANNING
    main_gui;
end