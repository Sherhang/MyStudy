To run the path_planning function type PATH_PLANNING. 

Version 1.0
-No updates

Version 1.1
-Design changed to GUI format
-Message prompts provide more information
-Ability to select goal points with cursor and by manual input
-Select map file using browse button
-Ability to view the start and goal points before calculation
-Ability to change graph output features such as goal and start positions
