# 回忆中的飞机大战

## 使用
```
环境: python3 + pygame

clone 此项目, 启动 manage.py 即可.
```

## 如图
![Image text](https://raw.githubusercontent.com/csrftoken/PlayPlane/master/material/play.jpg)

