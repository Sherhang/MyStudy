# QPSO_python
QPSO algorithm for multi-parameters optimization
