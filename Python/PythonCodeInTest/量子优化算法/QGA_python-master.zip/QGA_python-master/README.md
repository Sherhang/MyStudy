# QGA_python
QGA for multi-parameters optimization

QGA_RBF_SVM.py---基于QGA算法优化SVM的超参数。

rbf_data---样本数据集
